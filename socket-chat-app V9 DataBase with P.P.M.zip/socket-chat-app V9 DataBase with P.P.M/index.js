const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { MongoClient } = require('mongodb');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const port = 5000;

const uri = 'mongodb://localhost:27017'; // Replace with your MongoDB URI
const client = new MongoClient(uri);

let db;
let usersCollection;
let messagesCollection;

// Connect to MongoDB
client.connect()
    .then(() => {
        db = client.db('chatApp'); // Database name
        usersCollection = db.collection('users'); // Users collection
        messagesCollection = db.collection('messages'); // Messages collection
        console.log('Connected to MongoDB');
    })
    .catch(err => {
        console.error('MongoDB connection error:', err);
        process.exit(1); // Exit on failure
    });

const users = {}; // Track connected users in memory

// Serve static files
app.use(express.static(__dirname + '/public'));

// Redirect root to login page
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/login.html');
});

// WebSocket connection
io.on('connection', (socket) => {
    console.log('A user connected:', socket.id);

    // Register user
    socket.on('register', async (username) => {
        users[socket.id] = username;
        socket.username = username;

        // Save user to the database
        await usersCollection.updateOne(
            { username },
            { $set: { username, socketId: socket.id } },
            { upsert: true }
        );

        // Send message history to the connected user
        const messageHistory = await messagesCollection.find({}).sort({ time: 1 }).toArray();
        socket.emit('message history', messageHistory);

        // Broadcast updated user list
        io.emit('user list', Object.values(users));
    });

    // Handle public messages
    socket.on('public message', async (message) => {
        const messageData = {
            name: socket.username,
            message,
            time: new Date(),
            type: 'public',
        };

        // Save the message in the database
        await messagesCollection.insertOne(messageData);

        // Broadcast to all clients
        io.emit('public message', {
            ...messageData,
            time: messageData.time.toLocaleTimeString(),
        });
    });

    // Handle one-to-one messages
    socket.on('one-to-one message', async ({ recipient, message }) => {
        const recipientSocketId = Object.keys(users).find(id => users[id] === recipient);
        if (recipientSocketId) {
            const messageData = {
                sender: socket.username,
                recipient,
                message,
                time: new Date(),
                type: 'private',
            };

            // Save the message in the database
            await messagesCollection.insertOne(messageData);

            // Emit to recipient
            io.to(recipientSocketId).emit('one-to-one message', {
                ...messageData,
                time: messageData.time.toLocaleTimeString(),
            });

            // Emit to sender
            socket.emit('one-to-one message', {
                ...messageData,
                time: messageData.time.toLocaleTimeString(),
            });
        }
    });

    // Handle user disconnect
    socket.on('disconnect', async () => {
        const username = socket.username;
        delete users[socket.id];
        io.emit('user list', Object.values(users));

        // Remove user from the database
        await usersCollection.deleteOne({ username });
    });
});

// Start server
server.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
